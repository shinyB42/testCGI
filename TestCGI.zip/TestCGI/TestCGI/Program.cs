﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestCGI
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] array = new int[10] {8,3,9,4,10,12,5,2,8,1};

            printArray(array);
            Console.ReadLine();
        }

        public static void printArray(int[] array){
            int compteur = 0;
   
            for (int i = 0; i < array.Count(); i++)
            {
                compteur++;
                for (int j = compteur; j < array.Count(); j++)
                {
                    /*if (array[i] > array[j])
                    {
                        Console.WriteLine(array[i]);
                        //Console.WriteLine(Array.IndexOf(array, array[i]));
                        break;
                    }*/
                    Console.WriteLine(Array.IndexOf(array, array[j]));
                    //if (Array.IndexOf(array, array[i]) == Array.IndexOf(array, array[j])+1)
                    
                }
            }
        }

}
        

}
